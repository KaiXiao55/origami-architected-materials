clear all
files=dir(pwd);
for i=1:size(files,1)
    load(files(i).name,'rePoly')
    save(files(i).name,'rePoly')
end